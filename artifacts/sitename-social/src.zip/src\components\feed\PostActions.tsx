"use client";
import { useState } from "react";
import { Heart, MessageCircle, Send } from "lucide-react";
import type { Post } from "@/types";
import { useTranslation } from "@/i18n/useTranslation";

export function PostActions({ post }: { post: Post }) {
  const [liked, setLiked] = useState(false);
  const { t } = useTranslation();
  return <div className="flex items-center gap-1 border-t border-border px-4 py-2">
    <button onClick={() => setLiked((value) => !value)} aria-pressed={liked} className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-xs font-medium transition-colors hover:bg-surface-2 ${liked ? "text-danger" : "text-muted hover:text-text"}`}>
      <Heart size={17} fill={liked ? "currentColor" : "none"} />{t(liked ? "post.liked" : "post.like")}
    </button>
    <button className="flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-xs font-medium text-muted hover:bg-surface-2 hover:text-text"><MessageCircle size={17} />{post.comments} {t("post.comment")}</button>
    <button className="flex flex-1 items-center justify-center gap-2 rounded-lg py-2 text-xs font-medium text-muted hover:bg-surface-2 hover:text-text"><Send size={16} />{t("post.share")}</button>
  </div>;
}
