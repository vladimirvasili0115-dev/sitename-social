"use client";
import { Plus } from "lucide-react";
import type { Story } from "@/types";
import { Avatar } from "@/components/ui/Avatar";
import { useTranslation } from "@/i18n/useTranslation";

export function StoryItem({ story, add = false }: { story?: Story; add?: boolean }) {
  const { t } = useTranslation();
  const user = story?.user;
  return <button className="group flex w-[68px] shrink-0 flex-col items-center gap-2 text-center">
    <span className={`relative rounded-full p-[2px] ${add ? "bg-surface-2" : story?.seen ? "bg-border" : "bg-gradient-to-br from-accent to-accent-2"}`}>
      {user ? <Avatar user={user} className="h-[58px] w-[58px] border-[2px] border-bg transition-transform group-hover:scale-[1.03]" /> :
        <span className="flex h-[58px] w-[58px] items-center justify-center rounded-full border-[2px] border-bg bg-surface-2 text-muted"><Plus size={21} /></span>}
      {add && <span className="absolute bottom-0 right-0 flex h-5 w-5 items-center justify-center rounded-full border-2 border-bg bg-accent text-bg"><Plus size={12} strokeWidth={3} /></span>}
    </span>
    <span className="w-full truncate text-[11px] text-muted">{user?.name.split(" ")[0] ?? t("feed.addStory")}</span>
  </button>;
}
