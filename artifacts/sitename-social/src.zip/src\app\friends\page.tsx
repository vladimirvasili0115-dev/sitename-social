import { PlaceholderPage } from "@/components/ui/PlaceholderPage";
export default function FriendsPage() { return <PlaceholderPage titleKey="nav.friends" />; }
