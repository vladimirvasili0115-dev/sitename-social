"use client";
import { ChevronDown } from "lucide-react";
import { posts } from "@/data/posts";
import { useTranslation } from "@/i18n/useTranslation";
import { StoriesBar } from "@/components/feed/StoriesBar";
import { PostComposer } from "@/components/feed/PostComposer";
import { PostCard } from "@/components/feed/PostCard";
import { Card } from "@/components/ui/Card";

export default function FeedPage() {
  const { t } = useTranslation();
  return <div className="mx-auto max-w-[620px]">
    <div className="mb-5 flex items-end justify-between px-1">
      <div>
        <p className="mb-1 text-xs font-medium tracking-wide text-accent">{t("feed.greeting")}</p>
        <h1 className="text-[23px] font-semibold tracking-[-0.035em]">{t("feed.subtitle")}</h1>
      </div>
      <button aria-label={t("feed.latest")} className="mb-1 flex items-center gap-1 rounded-lg px-2 py-1 text-xs text-muted hover:bg-surface-2"><span>{t("feed.latest")}</span><ChevronDown size={14} /></button>
    </div>
    <StoriesBar />
    <PostComposer />
    <div className="mb-3 flex items-center gap-1 border-b border-border px-1">
      <button className="relative px-3 py-3 text-xs font-semibold text-accent">{t("feed.forYou")}<span className="absolute inset-x-3 bottom-0 h-0.5 rounded-full bg-accent" /></button>
      <button className="px-3 py-3 text-xs font-medium text-muted">{t("feed.following")}</button>
    </div>
    {posts.length ? posts.map((post) => <PostCard key={post.id} post={post} />) : <Card className="p-8 text-center text-sm text-muted">{t("feed.subtitle")}</Card>}
  </div>;
}
