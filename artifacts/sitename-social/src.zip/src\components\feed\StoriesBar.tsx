"use client";
import { stories } from "@/data/stories";
import { Card } from "@/components/ui/Card";
import { StoryItem } from "./StoryItem";
import { useTranslation } from "@/i18n/useTranslation";

export function StoriesBar() {
  const { t } = useTranslation();
  return <Card className="mb-4 overflow-hidden px-4 pb-3 pt-4">
    <div className="mb-3 flex items-center justify-between">
      <h2 className="text-sm font-semibold">{t("feed.stories")}</h2>
    </div>
    <div className="flex gap-3 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
      <StoryItem add />
      {stories.map((story) => <StoryItem key={story.id} story={story} />)}
    </div>
  </Card>;
}
