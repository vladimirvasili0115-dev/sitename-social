const az = {
  "nav.feed": "Lent", "nav.profile": "Profil", "nav.friends": "Dostlar", "nav.messages": "Mesajlar",
  "nav.groups": "Qruplar", "nav.photos": "Şəkillər", "nav.videos": "Videolar", "nav.games": "Oyunlar",
  "nav.music": "Musiqi", "nav.guests": "Qonaqlar", "nav.saved": "Saxlanılanlar", "nav.invisible": "Görünməz rejim",
  "nav.settings": "Tənzimləmələr", "nav.online": "Onlayn istifadəçilər", "nav.gifts": "Hədiyyələr",
  "nav.mainNavigation": "Əsas naviqasiya",
  "header.search": "Dostları və paylaşımları axtar", "header.messages": "Mesajlar", "header.notifications": "Bildirişlər",
  "header.profile": "Profil", "header.language": "Dil", "feed.greeting": "Salam, Aylin", "feed.subtitle": "Dostlarının həyatından yeni nə var?",
  "feed.stories": "Hekayələr", "feed.addStory": "Hekayə əlavə et", "feed.composer": "Ağlından nə keçir?",
  "feed.composerHint": "Kiçik anları paylaş, əlaqədə qal.", "feed.photo": "Foto", "feed.feeling": "Hiss",
  "feed.publish": "Paylaş", "feed.latest": "Ən son", "feed.forYou": "Sənin üçün", "feed.following": "İzlədiklərin",
  "post.like": "Bəyən", "post.liked": "Bəyəndin", "post.comment": "Şərh", "post.share": "Paylaş",
  "post.comments": "şərh", "post.minuteAgo": "dəqiqə əvvəl", "post.hourAgo": "saat əvvəl", "post.dayAgo": "gün əvvəl",
  "common.you": "Sən", "common.onlineNow": "İndi onlayn", "common.seeAll": "Hamısına bax", "common.friendsOnline": "Onlayn dostlar",
  "common.suggested": "Sənə uyğun ola bilər", "common.pageTitle": "Səhifə hazırlanır", "common.pageDescription": "Bu bölmə tezliklə burada olacaq.",
  "common.cancel": "Ləğv et", "common.search": "Axtar",
} as const;
export default az;
