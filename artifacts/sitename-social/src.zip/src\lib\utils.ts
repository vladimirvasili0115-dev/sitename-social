export function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

export function relativeTime(value: string, t: (key: "post.minuteAgo" | "post.hourAgo" | "post.dayAgo") => string) {
  const number = Number.parseInt(value, 10);
  if (value.endsWith("m")) return `${number} ${t("post.minuteAgo")}`;
  if (value.endsWith("h")) return `${number} ${t("post.hourAgo")}`;
  return `${number} ${t("post.dayAgo")}`;
}
