import { PlaceholderPage } from "@/components/ui/PlaceholderPage";
export default function VideosPage() { return <PlaceholderPage titleKey="nav.videos" />; }
