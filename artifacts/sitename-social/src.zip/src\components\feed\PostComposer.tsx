"use client";
import { Camera, Smile } from "lucide-react";
import { currentUser } from "@/data/users";
import { useTranslation } from "@/i18n/useTranslation";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";

export function PostComposer() {
  const { t } = useTranslation();
  return <Card className="mb-5 p-4">
    <div className="flex items-start gap-3">
      <Avatar user={currentUser} />
      <textarea aria-label={t("feed.composer")} placeholder={t("feed.composer")} rows={2} className="min-h-[58px] flex-1 resize-none rounded-xl border border-transparent bg-surface-2 px-4 py-3 text-sm text-text outline-none placeholder:text-muted focus:border-accent/40" />
    </div>
    <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
      <div className="flex gap-1">
        <Button variant="subtle" className="h-9 px-2.5 text-xs"><Camera size={16} className="text-accent" />{t("feed.photo")}</Button>
        <Button variant="subtle" className="h-9 px-2.5 text-xs"><Smile size={16} className="text-accent-2" />{t("feed.feeling")}</Button>
      </div>
      <Button className="px-4 py-2 text-xs">{t("feed.publish")}</Button>
    </div>
  </Card>;
}
