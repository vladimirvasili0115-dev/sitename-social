"use client";
import type { ReactNode } from "react";
import { Header } from "./Header";
import { Sidebar } from "./Sidebar";
import { MobileNav } from "./MobileNav";

export function AppShell({ children }: { children: ReactNode }) {
  return <div className="min-h-[100dvh] bg-bg text-text">
    <Header />
    <div className="mx-auto flex max-w-[1160px] items-start gap-6 px-4 pb-24 pt-6 md:px-6 lg:pb-10">
      <Sidebar />
      <main className="min-w-0 flex-1">{children}</main>
    </div>
    <MobileNav />
  </div>;
}
