import type { Story } from "@/types";
import { users } from "./users";

export const stories: Story[] = users.slice(1).map((user, index) => ({ id: `story-${user.id}`, user, seen: index === 3 }));
