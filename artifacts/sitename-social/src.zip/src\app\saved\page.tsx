import { PlaceholderPage } from "@/components/ui/PlaceholderPage";
export default function SavedPage() { return <PlaceholderPage titleKey="nav.saved" />; }
