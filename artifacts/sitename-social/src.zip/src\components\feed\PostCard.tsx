"use client";
import { MoreHorizontal } from "lucide-react";
import type { Post } from "@/types";
import { relativeTime } from "@/lib/utils";
import { useTranslation } from "@/i18n/useTranslation";
import { Avatar } from "@/components/ui/Avatar";
import { Card } from "@/components/ui/Card";
import { IconButton } from "@/components/ui/IconButton";
import { PostActions } from "./PostActions";

export function PostCard({ post }: { post: Post }) {
  const { t } = useTranslation();
  return <Card className="mb-4 overflow-hidden">
    <div className="flex items-center gap-3 px-4 pb-3 pt-4">
      <Avatar user={post.author} />
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-semibold">{post.author.name}</div>
        <div className="mt-0.5 text-[11px] text-muted">{relativeTime(post.time, t)}</div>
      </div>
      <IconButton aria-label={post.author.name} className="h-8 w-8"><MoreHorizontal size={19} /></IconButton>
    </div>
    <p className="px-4 pb-3 text-[13px] leading-6 text-text/90">{post.text}</p>
    {post.image && <img src={post.image} alt="" className="max-h-[420px] w-full object-cover" />}
    <div className="flex items-center justify-between px-4 py-3 text-xs text-muted">
      <div className="flex items-center gap-1.5"><span className="text-sm tracking-[-5px]">{post.reactions.join(" ")}</span><span className="ml-1">{post.likes}</span></div>
      <span>{post.comments} {t("post.comments")}</span>
    </div>
    <PostActions post={post} />
  </Card>;
}
