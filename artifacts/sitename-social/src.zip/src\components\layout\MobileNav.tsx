"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { navigation } from "@/config/navigation";
import { useTranslation } from "@/i18n/useTranslation";
import { cn } from "@/lib/utils";

const mobileHrefs = ["/feed", "/friends", "/messages", "/profile", "/groups"];
export function MobileNav() {
  const pathname = usePathname();
  const { t } = useTranslation();
  const items = navigation.filter((item) => mobileHrefs.includes(item.href));
  return (
    <nav aria-label={t("nav.mainNavigation")} className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-border bg-surface/95 px-1 pb-[env(safe-area-inset-bottom)] pt-1 backdrop-blur lg:hidden">
      {items.map(({ key, href, icon: Icon }) => {
        const active = pathname === href;
        return <Link key={href} href={href} className={cn("flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl text-[10px] font-medium", active ? "text-accent" : "text-muted")}>
          <Icon size={19} strokeWidth={active ? 2.4 : 1.8} /><span>{t(key as Parameters<typeof t>[0])}</span>
        </Link>;
      })}
    </nav>
  );
}
