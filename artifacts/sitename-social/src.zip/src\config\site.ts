export const SITE_NAME = "SITENAME";
