import { PlaceholderPage } from "@/components/ui/PlaceholderPage";
export default function GamesPage() { return <PlaceholderPage titleKey="nav.games" />; }
