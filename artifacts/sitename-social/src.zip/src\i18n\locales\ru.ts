import az from "./az";
const ru: Record<keyof typeof az, string> = {
  "nav.feed":"Лента","nav.profile":"Профиль","nav.friends":"Друзья","nav.messages":"Сообщения","nav.groups":"Группы","nav.photos":"Фото","nav.videos":"Видео","nav.games":"Игры","nav.music":"Музыка","nav.guests":"Гости","nav.saved":"Сохранённое","nav.invisible":"Режим невидимости","nav.settings":"Настройки","nav.online":"Сейчас онлайн","nav.gifts":"Подарки","nav.mainNavigation":"Главная навигация",
  "header.search":"Поиск друзей и публикаций","header.messages":"Сообщения","header.notifications":"Уведомления","header.profile":"Профиль","header.language":"Язык",
  "feed.greeting":"Привет, Айлин","feed.subtitle":"Что нового у друзей?","feed.stories":"Истории","feed.addStory":"Добавить историю","feed.composer":"О чём думаешь?","feed.composerHint":"Делись моментами и оставайся на связи.","feed.photo":"Фото","feed.feeling":"Настроение","feed.publish":"Опубликовать","feed.latest":"Сначала новые","feed.forYou":"Для вас","feed.following":"Подписки",
  "post.like":"Нравится","post.liked":"Нравится","post.comment":"Комментировать","post.share":"Поделиться","post.comments":"комментариев","post.minuteAgo":"минут назад","post.hourAgo":"час назад","post.dayAgo":"день назад",
  "common.you":"Вы","common.onlineNow":"Сейчас онлайн","common.seeAll":"Показать все","common.friendsOnline":"Друзья онлайн","common.suggested":"Возможно, вам интересно","common.pageTitle":"Страница готовится","common.pageDescription":"Этот раздел скоро появится.","common.cancel":"Отмена","common.search":"Поиск",
};
export default ru;
