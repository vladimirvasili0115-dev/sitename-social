import { PlaceholderPage } from "@/components/ui/PlaceholderPage";
export default function GuestsPage() { return <PlaceholderPage titleKey="nav.guests" />; }
