import az from "./az";
const tr: Record<keyof typeof az, string> = {
  "nav.feed":"Akış","nav.profile":"Profil","nav.friends":"Arkadaşlar","nav.messages":"Mesajlar","nav.groups":"Gruplar","nav.photos":"Fotoğraflar","nav.videos":"Videolar","nav.games":"Oyunlar","nav.music":"Müzik","nav.guests":"Ziyaretçiler","nav.saved":"Kaydedilenler","nav.invisible":"Görünmez mod","nav.settings":"Ayarlar","nav.online":"Çevrimiçi kişiler","nav.gifts":"Hediyeler","nav.mainNavigation":"Ana menü",
  "header.search":"Arkadaşları ve gönderileri ara","header.messages":"Mesajlar","header.notifications":"Bildirimler","header.profile":"Profil","header.language":"Dil",
  "feed.greeting":"Merhaba, Aylin","feed.subtitle":"Arkadaşlarının hayatında neler oluyor?","feed.stories":"Hikâyeler","feed.addStory":"Hikâye ekle","feed.composer":"Aklından neler geçiyor?","feed.composerHint":"Küçük anları paylaş, bağlantıda kal.","feed.photo":"Fotoğraf","feed.feeling":"His","feed.publish":"Paylaş","feed.latest":"En yeni","feed.forYou":"Senin için","feed.following":"Takip ettiklerin",
  "post.like":"Beğen","post.liked":"Beğendin","post.comment":"Yorum","post.share":"Paylaş","post.comments":"yorum","post.minuteAgo":"dakika önce","post.hourAgo":"saat önce","post.dayAgo":"gün önce",
  "common.you":"Sen","common.onlineNow":"Şu an çevrimiçi","common.seeAll":"Tümünü gör","common.friendsOnline":"Çevrimiçi arkadaşlar","common.suggested":"İlginizi çekebilir","common.pageTitle":"Sayfa hazırlanıyor","common.pageDescription":"Bu bölüm yakında burada olacak.","common.cancel":"Vazgeç","common.search":"Ara",
};
export default tr;
