import { PlaceholderPage } from "@/components/ui/PlaceholderPage";
export default function GiftsPage() { return <PlaceholderPage titleKey="nav.gifts" />; }
