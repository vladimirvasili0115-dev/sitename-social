import az from "./az";
const ka: Record<keyof typeof az, string> = {
  "nav.feed":"სიახლეები","nav.profile":"პროფილი","nav.friends":"მეგობრები","nav.messages":"შეტყობინებები","nav.groups":"ჯგუფები","nav.photos":"ფოტოები","nav.videos":"ვიდეოები","nav.games":"თამაშები","nav.music":"მუსიკა","nav.guests":"სტუმრები","nav.saved":"შენახული","nav.invisible":"უხილავი რეჟიმი","nav.settings":"პარამეტრები","nav.online":"ონლაინ მომხმარებლები","nav.gifts":"საჩუქრები","nav.mainNavigation":"მთავარი ნავიგაცია",
  "header.search":"მეგობრებისა და პოსტების ძიება","header.messages":"შეტყობინებები","header.notifications":"შეტყობინებები","header.profile":"პროფილი","header.language":"ენა",
  "feed.greeting":"გამარჯობა, აილინ","feed.subtitle":"ნახე, რას უზიარებენ მეგობრები ერთმანეთს.","feed.stories":"ისტორიები","feed.addStory":"ისტორიის დამატება","feed.composer":"რაზე ფიქრობ?","feed.composerHint":"გააზიარე პატარა მომენტები და შეინარჩუნე კავშირი.","feed.photo":"ფოტო","feed.feeling":"განწყობა","feed.publish":"გაზიარება","feed.latest":"უახლესი","feed.forYou":"შენთვის","feed.following":"გამოწერები",
  "post.like":"მომწონს","post.liked":"მოგეწონა","post.comment":"კომენტარი","post.share":"გაზიარება","post.comments":"კომენტარი","post.minuteAgo":"წუთის წინ","post.hourAgo":"საათის წინ","post.dayAgo":"დღის წინ",
  "common.you":"შენ","common.onlineNow":"ახლა ონლაინ","common.seeAll":"ყველას ნახვა","common.friendsOnline":"მეგობრები ონლაინ","common.suggested":"შეიძლება იცნობდე","common.pageTitle":"გვერდი მზადდება","common.pageDescription":"ეს განყოფილება მალე გამოჩნდება.","common.cancel":"გაუქმება","common.search":"ძიება",
};
export default ka;
