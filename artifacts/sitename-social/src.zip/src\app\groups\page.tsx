import { PlaceholderPage } from "@/components/ui/PlaceholderPage";
export default function GroupsPage() { return <PlaceholderPage titleKey="nav.groups" />; }
