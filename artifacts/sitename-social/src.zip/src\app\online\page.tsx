import { PlaceholderPage } from "@/components/ui/PlaceholderPage";
export default function OnlinePage() { return <PlaceholderPage titleKey="nav.online" />; }
