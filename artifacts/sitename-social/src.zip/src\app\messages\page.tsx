import { PlaceholderPage } from "@/components/ui/PlaceholderPage";
export default function MessagesPage() { return <PlaceholderPage titleKey="nav.messages" />; }
