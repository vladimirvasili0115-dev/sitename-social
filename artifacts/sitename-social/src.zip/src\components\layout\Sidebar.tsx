"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { navigation } from "@/config/navigation";
import { useTranslation } from "@/i18n/useTranslation";
import { Card } from "@/components/ui/Card";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const pathname = usePathname();
  const { t } = useTranslation();
  return (
    <aside className="sticky top-[96px] hidden h-fit w-[220px] shrink-0 lg:block">
      <Card className="overflow-hidden p-2">
        <nav className="space-y-0.5" aria-label={t("nav.mainNavigation")}>
          {navigation.map(({ key, href, icon: Icon, disabled }, index) => {
            const active = pathname === href && (href !== "/online" || key === "nav.online");
            const className = cn(
              "flex h-10 items-center gap-3 rounded-xl px-3 text-[13px] font-medium transition-colors",
              active ? "bg-accent/10 text-accent" : "text-muted hover:bg-surface-2 hover:text-text",
              disabled && "cursor-default hover:bg-transparent",
            );
            const content = <><Icon size={17} strokeWidth={active ? 2.25 : 1.8} /><span>{t(key as Parameters<typeof t>[0])}</span></>;
            return disabled
              ? <span key={`${key}-${index}`} aria-disabled="true" className={className}>{content}</span>
              : <Link key={`${key}-${index}`} href={href} aria-current={active ? "page" : undefined} className={className}>{content}</Link>;
          })}
        </nav>
      </Card>
    </aside>
  );
}
