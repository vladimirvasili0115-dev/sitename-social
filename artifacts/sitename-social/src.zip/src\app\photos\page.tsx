import { PlaceholderPage } from "@/components/ui/PlaceholderPage";
export default function PhotosPage() { return <PlaceholderPage titleKey="nav.photos" />; }
