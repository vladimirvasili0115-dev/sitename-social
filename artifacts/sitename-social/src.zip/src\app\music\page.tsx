import { PlaceholderPage } from "@/components/ui/PlaceholderPage";
export default function MusicPage() { return <PlaceholderPage titleKey="nav.music" />; }
