import az from "./az";
const en: Record<keyof typeof az, string> = {
  "nav.feed":"Feed","nav.profile":"Profile","nav.friends":"Friends","nav.messages":"Messages","nav.groups":"Groups","nav.photos":"Photos","nav.videos":"Videos","nav.games":"Games","nav.music":"Music","nav.guests":"Guests","nav.saved":"Saved","nav.invisible":"Invisible mode","nav.settings":"Settings","nav.online":"Online users","nav.gifts":"Gifts","nav.mainNavigation":"Main navigation",
  "header.search":"Search friends and posts","header.messages":"Messages","header.notifications":"Notifications","header.profile":"Profile","header.language":"Language",
  "feed.greeting":"Hello, Aylin","feed.subtitle":"Catch up on the little things your friends are sharing.","feed.stories":"Stories","feed.addStory":"Add story","feed.composer":"What's on your mind?","feed.composerHint":"Share a small moment. Stay close.","feed.photo":"Photo","feed.feeling":"Feeling","feed.publish":"Share","feed.latest":"Latest","feed.forYou":"For you","feed.following":"Following",
  "post.like":"Like","post.liked":"Liked","post.comment":"Comment","post.share":"Share","post.comments":"comments","post.minuteAgo":"minutes ago","post.hourAgo":"hours ago","post.dayAgo":"day ago",
  "common.you":"You","common.onlineNow":"Online now","common.seeAll":"See all","common.friendsOnline":"Friends online","common.suggested":"People you may know","common.pageTitle":"Page in the making","common.pageDescription":"This corner will be ready soon.","common.cancel":"Cancel","common.search":"Search",
};
export default en;
