"use client";
import { ChevronDown, Languages } from "lucide-react";
import { locales } from "@/i18n/config";
import { useTranslation } from "@/i18n/useTranslation";

export function LanguageSwitcher() {
  const { locale, setLocale, t } = useTranslation();
  const selected = locales.find((item) => item.code === locale) ?? locales[0];
  return (
    <label className="relative flex h-10 items-center gap-1 rounded-xl border border-border bg-surface px-3 text-sm text-text">
      <Languages size={15} className="text-muted" />
      <span>{selected.flag}</span><span className="uppercase">{selected.code}</span>
      <ChevronDown size={14} className="text-muted" />
      <select aria-label={t("header.language")} className="absolute inset-0 cursor-pointer opacity-0" value={locale} onChange={(event) => setLocale(event.target.value as typeof locale)}>
        {locales.map((item) => <option key={item.code} value={item.code}>{item.nativeName}</option>)}
      </select>
    </label>
  );
}
